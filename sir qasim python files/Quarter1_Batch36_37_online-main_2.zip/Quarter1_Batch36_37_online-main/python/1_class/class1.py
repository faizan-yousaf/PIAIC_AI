print("Pakistan zinda bad!")
print("Hello World!")
