def f1():
    return "function1 body from attendance module"

def f2():
    return "function2 body from attendance module"

def f3():
    return "function3 body from attendance module"

def f4():
    return "function4 body from attendance module"