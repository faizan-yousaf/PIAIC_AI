def f1():
    return "function1 body from maths module"

def f2():
    return "function2 body from maths module"

def f3():
    return "function3 body from maths module"

def f4():
    return "function4 body from maths module"