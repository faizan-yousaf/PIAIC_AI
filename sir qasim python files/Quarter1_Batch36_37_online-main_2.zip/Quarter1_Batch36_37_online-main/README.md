# PGD Batach-3 

# First Class
* Introduction
* Six ways to print hello world in python
* Variable
* Operators and Oprands
